import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';
import gallery1 from "./../../img/download.jpeg";
import gallery2 from "./../../img/download1.jpg";
import gallery3 from "./../../img/download2.jpeg";
import Carousel from './Caurosal';

const CarouselComponent = () => {
  const images = [
    { src: gallery1, alt: "Los Angeles" },
    { src: gallery2, alt: "Chicago" },
    { src: gallery3, alt: "New York" }
  ];

  return (
    <div>
      <Carousel images={images} />
<div className='container'>
  <div className='row'>
    
  </div>
</div>


    </div>
  );
}

export default CarouselComponent;
