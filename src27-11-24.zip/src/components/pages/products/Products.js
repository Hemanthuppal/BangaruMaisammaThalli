import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Carousel } from 'react-bootstrap';
import gallery1 from "./../../img/2-2.jpg";
import gallery2 from "./../../img/3-2.jpg";
import gallery3 from "./../../img/4-2.jpg";
import gallery4 from "./../../img/8-1.jpg";
import gallery5 from "./../../img/5-2.jpg";
import gallery6 from "./../../img/6-2.jpg";
import gallery7 from "./../../img/7-1.jpg";
import gallery8 from "./../../img/8-1.jpg";
import gallery9 from "./../../img/9-1.jpg";
import "./Product.css";

const Products = () => {
  const images = [
    gallery1, gallery2, gallery3,
    gallery4, gallery5, gallery6,
    gallery7, gallery8, gallery9
  ];

  const [showCarousel, setShowCarousel] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);

  const openCarousel = (index) => {
    setCurrentIndex(index);
    setShowCarousel(true);
  };

  const closeCarousel = (e) => {
    // Close only if clicked outside the carousel content
    if (e.target.classList.contains('carousel-overlay')) {
      setShowCarousel(false);
    }
  };

  const handleSelect = (selectedIndex) => {
    setCurrentIndex(selectedIndex);
  };

  return (
    <div className='gallery-background'>
      <div className='container' style={{ marginTop: "100px" }}>
        <div className='row'>
          {images.map((image, index) => (
            <div className='col-md-4' key={index}>
              <img
                src={image}
                className='img-fluid gallery-img'
                alt={`Gallery ${index + 1}`}
                onClick={() => openCarousel(index)}
                style={{ cursor: "pointer" }}
              />
            </div>
          ))}
        </div>

        {/* Carousel Overlay */}
        {showCarousel && (
          <div className="carousel-overlay" onClick={closeCarousel}>
            <Carousel 
              activeIndex={currentIndex} 
              onSelect={handleSelect} 
              indicators={false} 
              interval={null} 
              controls
            >
              {images.map((image, index) => (
                <Carousel.Item key={index}>
                  <img src={image} alt={`Gallery ${index + 1}`} className="d-block w-100" />
                </Carousel.Item>
              ))}
            </Carousel>
          </div>
        )}
      </div>
    </div>
  );
};

export default Products;
